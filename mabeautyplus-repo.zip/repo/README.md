# mabeautyplus.fr

Site statique de MAbeautyplus, généré en Python et déployé sur Netlify.
Remplace le site Wix Studio.

---

## Structure

```
.
├── dist/                      ← LE SITE GÉNÉRÉ (c'est ce que Netlify publie)
├── src/
│   ├── build.py               ← script de build (point d'entrée)
│   ├── parcours.py            ← contenu + gabarit des pages « parcours »
│   ├── parts/                 ← shell commun
│   │   ├── head.tpl.html      ← <head> paramétrable (title, desc, canonical, GTM, Pixel)
│   │   ├── base.css           ← CSS repris de la LP perte de poids
│   │   ├── header.html        ← header + menu mobile
│   │   ├── footer.html        ← footer + sticky CTA
│   │   ├── form.html          ← bloc formulaire (ancre #inscription)
│   │   ├── mid.html           ← </head><body> + noscript GTM
│   │   └── scripts.html       ← JS commun (menu, FAQ, carrousels, formulaire)
│   └── pages/
│       ├── index.body.html    ← corps de la page d'accueil
│       └── index.jsonld.json  ← JSON-LD Organization + 5 LocalBusiness
├── netlify/functions/lead.js  ← réception des leads → Airtable
├── scripts/check_links.py     ← vérification avant déploiement
└── netlify.toml               ← publication, en-têtes, redirections 301
```

**Règle importante :** ne jamais éditer un fichier de `dist/` à la main.
Tout se modifie dans `src/`, puis on rebuild. `dist/` est écrasé à chaque build.

---

## Build

```bash
cd src && python3 build.py
```

Aucune dépendance externe : Python 3 standard suffit.

Ce que ça génère :

| Type | Pages |
|---|---|
| Accueil | `/` |
| Parcours | `/perte-de-poids` |
| Centres | `/centres` + les 5 fiches |
| Divers | `/avis`, `/contact` |
| Légal | `/mentions-legales`, `/politique-de-confidentialite`, `/cgv` |
| Technique | `404.html`, `sitemap.xml`, `robots.txt` |

### Modifier le header, le footer ou le formulaire

Édite le fichier concerné dans `src/parts/`, rebuild : la modification se
propage sur **toutes** les pages. C'est le même principe que la skill des LP
centres.

### Modifier un centre

Tout est dans le tableau `CENTRES` de `src/build.py` : adresse, coordonnées
GPS, note Google, leviers disponibles, communes desservies. Rebuild et les
5 fiches sont régénérées.

### Ajouter un parcours

Ajoute une entrée dans la liste `PARCOURS` de `src/parcours.py`. Le gabarit
(hero, douleurs, piliers, bénéfices, FAQ, témoignages, formulaire) est
commun — tu ne remplis que le contenu.

---

## Vérification avant déploiement

```bash
python3 scripts/check_links.py
```

Contrôle l'équilibre des balises, la validité du JSON-LD, les identifiants
dupliqués, la présence du tracking et du canonical, les allégations
commerciales interdites, et les liens internes cassés.

**Ce script doit sortir `PRÊT À DÉPLOYER` avant toute bascule DNS.**

---

## Déploiement

### 1. GitHub

```bash
git init
git add .
git commit -m "Refonte mabeautyplus.fr — site statique"
git branch -M main
git remote add origin git@github.com:<ton-compte>/mabeautyplus.git
git push -u origin main
```

### 2. Netlify

Add new site → Import an existing project → GitHub → sélectionner le dépôt.
Les réglages sont lus depuis `netlify.toml`, il n'y a rien à saisir à la main.

Si tu préfères ne pas builder sur Netlify, remplace la ligne `command` de
`netlify.toml` par `command = ""` et commit le dossier `dist/` (il est déjà
versionné).

### 3. Variables d'environnement

Site settings → Environment variables :

| Variable | Valeur |
|---|---|
| `AIRTABLE_TOKEN` | Personal Access Token Airtable, scope `data.records:write` |
| `AIRTABLE_BASE` | `appNML7rJEKiWkuVg` |
| `AIRTABLE_TABLE` | `tblgCdNITlPy74Z5G` |

⚠️ Vérifier que la constante `FIELDS` en haut de `netlify/functions/lead.js`
correspond exactement aux noms des colonnes de la table Airtable, accents
compris. C'est la cause n°1 des leads qui ne remontent pas.

### 4. Domaine

Domain settings → Add custom domain → `www.mabeautyplus.fr`, puis passer les
enregistrements chez OVH. Cocher la redirection du domaine nu vers `www`.

---

## À faire avant la bascule

- [ ] Créer les **12 pages manquantes** : `/menopause`, `/stress-sommeil`,
      `/anti-age`, `/luxotherapie`, `/reeducation-alimentaire`, `/i-shape`,
      `/pressodynamie`, `/cavitalyse`, `/adipologie`, `/new-sequential`,
      `/mesojet`, `/advance-lift`.
      Plusieurs redirections 301 de `netlify.toml` pointent vers elles.
- [ ] Ajouter les **favicons** à la racine de `dist/` : `favicon.ico`,
      `favicon-16.png`, `favicon-32.png`, `apple-touch-icon.png`
      (les mêmes que sur les LP).
- [ ] Compléter les **mentions légales** : raison sociale, forme juridique,
      capital, SIRET, RCS, TVA, directeur de publication.
- [ ] Compléter les **CGV** : modalités de paiement, durée de validité des
      séances, coordonnées du médiateur de la consommation.
      **Faire relire par un juriste.**
- [ ] Installer un **bandeau de consentement cookies** qui bloque GTM et le
      Pixel avant l'accord. Aujourd'hui ils se déclenchent au chargement :
      ce n'est pas conforme sur un site indexé.
- [ ] Remplacer les **photos placeholder** de la galerie et du hero.
- [ ] Lancer `python3 scripts/check_links.py` → doit être vert.

## Après la bascule

- [ ] Search Console : soumettre `https://www.mabeautyplus.fr/sitemap.xml`
- [ ] Vérifier les 301 depuis les anciennes URLs Wix (`/legrauduroi`,
      `/ishape`, `/luxotherapie-menopause`…)
- [ ] Tag Assistant : contrôler GTM, GA4, Google Ads et le Pixel sur une
      soumission réelle de formulaire
- [ ] Vérifier qu'un lead de test arrive bien dans Airtable avec
      `Source = Site` et `Statut = Nouveau`

---

## Tracking en place

| Outil | Identifiant |
|---|---|
| Google Tag Manager | `GTM-NTQBZS4D` |
| Meta Pixel | `301574138086843` |

Événements envoyés à la soumission du formulaire :
`fbq('track','Lead')` et `dataLayer.push({event:'lead_form', form_source, objectif, centre})`.
Au clic Calendly : `fbq('track','Schedule')` et `dataLayer.push({event:'rdv_calendly'})`.
