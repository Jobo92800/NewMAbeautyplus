/**
 * MAbeautyplus — réception des leads du site
 * POST /.netlify/functions/lead
 *
 * Écrit une ligne dans Airtable avec Statut = "Nouveau".
 *
 * Variables d'environnement à définir dans Netlify
 * (Site settings → Environment variables) :
 *   AIRTABLE_TOKEN   Personal Access Token Airtable (scope data.records:write)
 *   AIRTABLE_BASE    appNML7rJEKiWkuVg
 *   AIRTABLE_TABLE   tblgCdNITlPy74Z5G
 *
 * ⚠️ FIELDS ci-dessous doit correspondre EXACTEMENT aux noms des colonnes
 *    de ta table Airtable (majuscules et accents compris).
 */

const FIELDS = {
  prenom:    'Prénom',
  nom:       'Nom',
  telephone: 'Téléphone',
  email:     'Email',
  centre:    'Centre',
  soins:     'Soins',
  source:    'Source',
  statut:    'Statut',
};

const STATUT_INITIAL = 'Nouveau';

const CORS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': 'https://www.mabeautyplus.fr',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const reply = (statusCode, body) => ({
  statusCode,
  headers: CORS,
  body: JSON.stringify(body),
});

// Normalise un numéro français en 0X XX XX XX XX
function normalisePhone(raw) {
  const d = String(raw).replace(/[^\d+]/g, '').replace(/^\+33/, '0');
  return d.length === 10 ? d.replace(/(\d{2})(?=\d)/g, '$1 ').trim() : String(raw).trim();
}

const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
const isPhone = (v) => String(v).replace(/\D/g, '').length >= 9;

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Méthode non autorisée.' });

  const { AIRTABLE_TOKEN, AIRTABLE_BASE, AIRTABLE_TABLE } = process.env;
  if (!AIRTABLE_TOKEN || !AIRTABLE_BASE || !AIRTABLE_TABLE) {
    console.error('Variables Airtable manquantes');
    return reply(500, { error: "Configuration serveur incomplète. Appelez-nous au 04 66 73 02 00." });
  }

  let data;
  try {
    data = JSON.parse(event.body || '{}');
  } catch {
    return reply(400, { error: 'Requête invalide.' });
  }

  // Honeypot anti-spam (champ caché éventuel)
  if (data.website) return reply(200, { ok: true });

  const prenom    = String(data.prenom    || '').trim();
  const nom       = String(data.nom       || '').trim();
  const telephone = String(data.telephone || '').trim();
  const email     = String(data.email     || '').trim().toLowerCase();
  const centre    = String(data.centre    || '').trim();
  const soins     = String(data.soins     || '').trim();
  const source    = String(data.source    || 'Site').trim();

  if (!prenom || !nom || !telephone || !email || !centre) {
    return reply(400, { error: 'Merci de remplir tous les champs obligatoires.' });
  }
  if (!isEmail(email))  return reply(400, { error: "L'adresse e-mail ne semble pas valide." });
  if (!isPhone(telephone)) return reply(400, { error: 'Le numéro de téléphone ne semble pas valide.' });

  const fields = {
    [FIELDS.prenom]:    prenom,
    [FIELDS.nom]:       nom,
    [FIELDS.telephone]: normalisePhone(telephone),
    [FIELDS.email]:     email,
    [FIELDS.centre]:    centre,
    [FIELDS.source]:    source,
    [FIELDS.statut]:    STATUT_INITIAL,
  };
  if (soins) fields[FIELDS.soins] = soins;

  try {
    const res = await fetch(
      `https://api.airtable.com/v0/${AIRTABLE_BASE}/${AIRTABLE_TABLE}`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${AIRTABLE_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ records: [{ fields }], typecast: true }),
      }
    );

    if (!res.ok) {
      const detail = await res.text();
      console.error('Airtable', res.status, detail);
      return reply(502, { error: "Une erreur est survenue. Réessayez ou appelez-nous au 04 66 73 02 00." });
    }

    return reply(200, { ok: true });
  } catch (err) {
    console.error('lead.js', err);
    return reply(500, { error: "Une erreur est survenue. Réessayez ou appelez-nous au 04 66 73 02 00." });
  }
};
