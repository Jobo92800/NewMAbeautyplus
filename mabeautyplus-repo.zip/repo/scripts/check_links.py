#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vérification avant déploiement.
Usage : python3 scripts/check_links.py

Contrôle sur tout le contenu de dist/ :
  - équilibre des balises HTML
  - validité du JSON-LD
  - identifiants HTML dupliqués
  - présence du tracking, du canonical et de l'ancre #inscription
  - allégations commerciales interdites
  - liens internes pointant vers une page inexistante
Code de sortie 1 si un problème est détecté (utilisable en CI).
"""
import re, os, sys, json, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST = os.path.join(ROOT, 'dist')

VOID = {'meta','link','img','br','hr','input','source','area','base','col','embed','param','track','wbr'}
INTERDIT = ['95,6', '95 %', '2-4 kg', '90% Satisfaction', 'validée et efficace',
            '49 €', '49€', '€ par séance', 'PSIO', '{{']
REQUIS = [('id="inscription"', 'ancre #inscription'),
          ('GTM-NTQBZS4D', 'Google Tag Manager'),
          ('301574138086843', 'Meta Pixel'),
          ('rel="canonical"', 'canonical')]

def pages():
    for f in sorted(glob.glob(os.path.join(DIST, '**', '*.html'), recursive=True)):
        yield f, open(f, encoding='utf-8').read()

def route(f):
    rel = os.path.relpath(f, DIST)
    if rel == 'index.html': return '/'
    if rel == '404.html':   return '/404'
    return '/' + os.path.dirname(rel).replace(os.sep, '/')

def balance(s):
    stack, errs = [], []
    for close, name, sc in re.findall(r'<(/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*?(/?)>', s):
        n = name.lower()
        if n in VOID or sc: continue
        if not close: stack.append(n)
        elif not stack: errs.append(f'</{n}> orphelin'); break
        elif stack[-1] != n: errs.append(f'attendu </{stack[-1]}>, trouvé </{n}>'); break
        else: stack.pop()
    if stack: errs.append(f'non fermées : {stack[-4:]}')
    return errs

def main():
    if not os.path.isdir(DIST):
        print('dist/ introuvable — lance d’abord : python3 src/build.py'); return 1

    routes, problemes, liens = set(), 0, {}
    for f, s in pages():
        routes.add(route(f))

    for f, s in pages():
        r, msgs = route(f), []
        msgs += balance(s)
        for m in re.findall(r'<script type="application/ld\+json">(.*?)</script>', s, re.S):
            try: json.loads(m)
            except Exception as e: msgs.append(f'JSON-LD invalide : {e}')
        ids = re.findall(r'\sid="([^"]+)"', s)
        dup = sorted({i for i in ids if ids.count(i) > 1})
        if dup: msgs.append(f'id dupliqués : {dup}')
        found = [c for c in INTERDIT if c in s]
        if found: msgs.append(f'contenu interdit : {found}')
        if r != '/404':
            for needle, label in REQUIS:
                if needle not in s: msgs.append(f'manque : {label}')
        for l in re.findall(r'href="(/[^"#?]*)"', s):
            if l.endswith(('.png', '.ico', '.xml', '.txt', '.jpg', '.webp', '.svg')): continue
            liens.setdefault(l.rstrip('/') or '/', set()).add(r)
        if msgs:
            problemes += 1
            print(f'✗ {r}')
            for m in msgs: print(f'    {m}')
        else:
            print(f'✓ {r}')

    casses = {l: src for l, src in liens.items() if l not in routes}
    if casses:
        print(f'\n✗ {len(casses)} lien(s) interne(s) vers une page inexistante :')
        for l, src in sorted(casses.items()):
            print(f'    {l}   ← cité par : {", ".join(sorted(src))}')
        problemes += 1
    else:
        print('\n✓ tous les liens internes résolvent')

    print('\n' + ('PRÊT À DÉPLOYER' if not problemes else f'{problemes} point(s) à corriger avant bascule DNS'))
    return 1 if problemes else 0

if __name__ == '__main__':
    sys.exit(main())
