# -*- coding: utf-8 -*-
"""
Pages « parcours » (accompagnements) du site MAbeautyplus.
Un gabarit commun + un dictionnaire de contenu par parcours.
Importé par build.py.
"""

CSS_PARCOURS = """
/* ---------- Pages parcours ---------- */
.quote-band{background:var(--teal);color:#fff;padding:52px 0;text-align:center}
.quote-band p{font-size:clamp(1.25rem,3.2vw,1.75rem);font-weight:700;max-width:840px;margin:0 auto;line-height:1.4}
.quote-band small{display:block;margin-top:14px;font-size:.95rem;font-weight:500;opacity:.9}
.bengrid{display:grid;gap:20px;margin-top:42px}
@media(min-width:680px){.bengrid{grid-template-columns:1fr 1fr}}
@media(min-width:1000px){.bengrid{grid-template-columns:repeat(3,1fr)}}
.ben{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:26px 22px;box-shadow:var(--shadow)}
.ben h3{font-size:1.08rem;margin-bottom:9px;color:var(--dark-title)}
.ben p{color:var(--muted);font-size:.94rem}
.ben .dot{width:38px;height:38px;border-radius:11px;background:var(--blush);color:var(--pink);
  display:grid;place-items:center;font-weight:800;margin-bottom:14px;font-size:.95rem}
.forwho{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:30px 28px;
  max-width:760px;margin:38px auto 0;box-shadow:var(--shadow)}
.forwho ul{list-style:none}
.forwho li{padding-left:30px;position:relative;margin-bottom:13px;color:var(--mid);font-size:1rem}
.forwho li::before{content:"";position:absolute;left:2px;top:7px;width:14px;height:8px;
  border-left:2.5px solid var(--teal);border-bottom:2.5px solid var(--teal);transform:rotate(-45deg)}
.pill-apply{display:grid;gap:20px;margin-top:42px}
@media(min-width:680px){.pill-apply{grid-template-columns:1fr 1fr}}
.pa{background:#fff;border:1px solid var(--line);border-left:4px solid var(--teal);
  border-radius:14px;padding:24px 24px}
.pa .n{font-size:.7rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--pink);margin-bottom:8px}
.pa h3{font-size:1.1rem;margin-bottom:9px}
.pa p{color:var(--muted);font-size:.94rem}
.pa a.more{display:inline-block;margin-top:12px;font-weight:700;font-size:.88rem;color:var(--teal-dark)}
"""

# ═══════════════════════════════════════════════════════════════
#  CONTENU DES PARCOURS
# ═══════════════════════════════════════════════════════════════
PARCOURS = [
{
 'slug':'perte-de-poids',
 'nav':'Perte de poids',
 'title':'Perte de poids | La méthode globale MAbeautyplus',
 'desc':"Perdre du poids en agissant sur la cause : métabolisme, alimentation, sommeil, stress et émotions. "
        "Analyse de composition corporelle offerte dans nos 5 centres du Sud de la France.",
 'ogdesc':"Agir sur la cause, pas seulement sur la balance.",
 'eyebrow':'Accompagnement perte de poids',
 'h1':'Perdre du poids en agissant sur <em>la cause</em>,<br>pas seulement sur la balance',
 'sub':"Vous avez déjà essayé les régimes, le sport, les applications de comptage. Et le poids finit toujours par "
       "revenir. C'est rarement un problème de volonté : c'est le signe qu'on s'est attaqué au symptôme plutôt "
       "qu'à ce qui bloque réellement.",

 'pains':[
   "Votre métabolisme semble « bloqué » et plus rien ne bouge, quoi que vous fassiez ?",
   "Vous grignotez sous l'effet du stress ou des émotions, sans vraiment le contrôler ?",
   "Vous avez tout essayé — régimes, sport — mais le poids finit toujours par revenir ?",
   "Certaines zones résistent (ventre, hanches, cuisses) malgré tous vos efforts ?",
   "Vous vous sentez ballonné, les jambes lourdes, avec de la rétention d'eau ?",
   "Vous dormez mal, vous êtes fatigué, et l'énergie manque pour tenir dans la durée ?",
 ],
 'tags':['Métabolisme','Alimentation','Stress','Sommeil','Hormones','Graisse viscérale','Émotions'],

 'quote':"On ne vous met pas au régime. On comprend d'abord pourquoi votre corps stocke.",
 'quote_sub':"C'est la différence entre perdre du poids et le reprendre, et perdre du poids et le stabiliser.",

 'intro_title':"Ce n'est pas qu'une question de <span class=\"pink-text\">volonté</span>",
 'intro_lead':"Quand le stress s'installe, le corps se dérègle. Les envies alimentaires augmentent, la culpabilité "
              "aussi, et la perte de poids devient de plus en plus difficile.",
 'intro_body':"Chez MAbeautyplus, nous partons d'une analyse chiffrée de votre composition corporelle : masse "
              "grasse, graisse viscérale, masse musculaire, eau corporelle et métabolisme de base. Ces données "
              "nous disent ce qui se passe réellement dans votre corps — et c'est à partir de là, et seulement de "
              "là, que nous construisons votre accompagnement.",

 'piliers':[
   ('Pilier 1','Luxothérapie','/luxotherapie',
    "Une stimulation infrarouge de points réflexes, sans aiguille et en position allongée. Elle vise le "
    "métabolisme, les compulsions alimentaires, le stress et la qualité du sommeil — les quatre facteurs qui "
    "font le plus souvent échouer une perte de poids."),
   ('Pilier 2','Rééducation alimentaire','/reeducation-alimentaire',
    "Pas de régime, pas de suppression d'aliments. Un cadre structuré, un guide de recettes et un suivi pour "
    "réapprendre à manger, gérer les écarts sans culpabilité et tenir sur la durée."),
   ('Pilier 3','I-Shape','/i-shape',
    "L'électrostimulation allongée travaille la tonicité musculaire et participe au maintien de la masse "
    "maigre pendant la perte de poids. C'est ce qui fait la différence entre maigrir et s'affiner."),
   ('Pilier 4','Pressodynamie','/pressodynamie',
    "Le drainage lymphatique agit sur la rétention d'eau, les jambes lourdes et la cellulite aqueuse. "
    "Une sensation de légèreté dès les premières séances, et une silhouette qui s'affine visiblement."),
 ],

 'benefits':[
   ('Agir sur le métabolisme',"L'accompagnement vise à relancer un métabolisme ralenti par les régimes "
    "successifs, plutôt qu'à réduire encore les apports."),
   ('Apaiser les compulsions',"Fringales, grignotages, envies de sucre : nous travaillons sur ce qui les "
    "déclenche plutôt que sur la seule maîtrise de soi."),
   ('Sans effort physique',"Les séances se déroulent allongé, habillé, dans un cadre calme. Aucune contrainte "
    "sportive n'est imposée."),
   ('Améliorer le sommeil',"Un sommeil de meilleure qualité est un facteur clé de la perte de poids — et "
    "l'un des premiers changements que nos clients rapportent."),
   ('Prendre en compte le stress',"Le stress chronique participe au stockage des graisses. Il fait donc partie "
    "intégrante de l'accompagnement, pas d'un discours à côté."),
   ('Stabiliser dans la durée',"L'objectif n'est pas de perdre vite. Le suivi se poursuit jusqu'à la "
    "stabilisation, pour éviter la reprise."),
 ],

 'forwho_title':"À qui s'adresse cet accompagnement ?",
 'forwho':[
   "Vous avez déjà essayé plusieurs régimes, sans résultat durable.",
   "Vous mangez plutôt correctement, mais vous n'arrivez plus à perdre.",
   "Vous souffrez de fringales, de fatigue, de stress ou de troubles du sommeil.",
   "Vous traversez une période hormonale particulière : ménopause, post-grossesse.",
   "Vous faites du sport, mais votre corps stocke malgré tout.",
   "Vous voulez perdre du poids durablement, sans régime strict ni frustration.",
 ],
 'forwho_note':"Ce n'est pas une méthode miracle. C'est une approche physiologique et individualisée, "
               "adaptée à chaque métabolisme — et elle commence toujours par une analyse.",

 'steps':[
   ("L'analyse offerte","Environ 30 minutes : un échange sur votre parcours, vos blocages et vos objectifs, "
    "puis une analyse de composition corporelle. Vous repartez en sachant précisément où vous en êtes."),
   ("Votre protocole","À partir de vos données, nous définissons les leviers activés, leur ordre et leur "
    "fréquence. Le nombre de séances est déterminé par l'analyse, jamais fixé à l'avance."),
   ("Le suivi jusqu'à la stabilisation","Votre praticienne vous suit séance après séance, ajuste le protocole "
    "et vous accompagne au-delà de l'objectif atteint, pour installer les acquis."),
 ],

 'faq':[
  ("Comment fonctionne la méthode MAbeautyplus pour la perte de poids ?",
   "Elle repose sur la combinaison de quatre leviers : la luxothérapie infrarouge, qui agit sur des points "
   "réflexes liés au métabolisme, aux envies alimentaires, au stress et au sommeil ; la rééducation alimentaire, "
   "qui installe un cadre durable sans restriction extrême ; l'I-Shape, qui travaille la tonicité musculaire ; "
   "et la pressodynamie, qui agit sur la circulation et la rétention d'eau. C'est votre analyse de composition "
   "corporelle qui détermine lesquels sont pertinents pour vous, et dans quelles proportions."),
  ("Comment se déroule une séance ?",
   "La séance de luxothérapie se fait en position allongée, habillé, sans douleur, sans aiguille et sans "
   "manipulation invasive, dans un cadre calme et encadré par une praticienne formée. Elle dure environ "
   "30 minutes — une durée volontairement maîtrisée, pour une stimulation efficace sans surstimulation inutile."),
  ("Combien de séances faut-il prévoir ?",
   "Le protocole repose sur un socle minimum, à raison d'environ une séance par semaine. Le nombre exact est "
   "toujours défini à partir de votre analyse de composition corporelle, parce que chaque corps réagit "
   "différemment. Les séances ne sont pas vendues à l'unité : elles s'inscrivent dans un protocole structuré, "
   "pensé pour des résultats qui tiennent."),
  ("Vais-je devoir suivre un régime ?",
   "Non. Nous ne pratiquons ni régime ni suppression d'aliments. La rééducation alimentaire consiste à "
   "réapprendre à manger : un cadre clair, des recettes variées, et surtout la capacité de gérer les écarts "
   "sans culpabiliser. C'est précisément ce qui évite l'effet yoyo."),
  ("Y a-t-il des contre-indications ?",
   "La luxothérapie est une méthode douce et non invasive, mais elle comporte des contre-indications totales : "
   "la grossesse et les troubles épileptiques. D'autres situations nécessitent un avis préalable lors de "
   "l'analyse : pathologies médicales spécifiques, traitements lourds en cours, cas particuliers évalués "
   "individuellement. C'est l'une des raisons pour lesquelles l'analyse initiale est indispensable."),
  ("Quels résultats puis-je attendre ?",
   "Les résultats varient d'une personne à l'autre selon la physiologie, le point de départ, l'assiduité et le "
   "respect des recommandations. Nous ne promettons pas de chiffre : l'analyse initiale sert justement à définir "
   "avec vous un objectif réaliste et atteignable. Ce que nous garantissons, c'est le cadre et le suivi."),
  ("Combien ça coûte ?",
   "L'analyse de composition corporelle et l'entretien initial sont offerts, sans aucun engagement. Les tarifs "
   "de l'accompagnement vous sont présentés à l'issue de cette analyse, une fois le protocole défini — parce "
   "qu'ils dépendent de ce dont vous avez réellement besoin. Vous décidez ensuite en connaissance de cause."),
  ("Les hommes sont-ils accueillis ?",
   "Oui. La méthode s'applique de la même façon et l'analyse de composition corporelle est tout aussi "
   "pertinente. Nos centres accueillent aussi bien les hommes que les femmes."),
 ],

 'testi':[
  ("Après plusieurs régimes essayés sans résultat, j'ai enfin trouvé une méthode qui fonctionne. Et surtout, "
   "pas de reprise après la cure.","Sandrine M."),
  ("On m'a reçue avec une vraie analyse corporelle, pas un programme passe-partout. Je me sens enfin bien dans "
   "mon corps.","Karine L."),
  ("Ce que j'ai préféré : on ne m'a pas mise au régime. J'ai retrouvé un équilibre alimentaire que je tiens "
   "encore aujourd'hui.","Valérie D."),
  ("Les séances sont un vrai moment pour soi, allongée et sans effort. Et les centimètres partent vraiment, "
   "séance après séance.","Nathalie P."),
  ("J'étais sceptique au départ. Dans ma tête je partais sur un régime, alors qu'il s'agit d'une autre façon de "
   "manger, qui n'a rien d'un régime.","Marielle C."),
  ("Un accompagnement humain, sans jugement. L'équipe m'a suivie du début à la fin.","Florence R."),
 ],
},
]

# ═══════════════════════════════════════════════════════════════
#  GABARIT
# ═══════════════════════════════════════════════════════════════
def build_parcours(p, FORM, crumb, CENTRES):
    pains = ''.join(f'<div class="pcard"><p>{t}</p></div>' for t in p['pains'])
    tags  = ''.join(f'<span>{t}</span>' for t in p['tags'])
    pil   = ''.join(f'''
      <div class="pa"><div class="n">{n}</div><h3>{t}</h3><p>{d}</p>
      <a class="more" href="{u}">En savoir plus sur {t} →</a></div>''' for n, t, u, d in p['piliers'])
    ben   = ''.join(f'<div class="ben"><div class="dot">{i+1}</div><h3>{t}</h3><p>{d}</p></div>'
                    for i, (t, d) in enumerate(p['benefits']))
    who   = ''.join(f'<li>{l}</li>' for l in p['forwho'])
    steps = ''.join(f'<div class="step"><h3>{t}</h3><p>{d}</p></div>' for t, d in p['steps'])
    faq   = ''.join(f'<div class="faq-item"><div class="faq-q">{q}</div>'
                    f'<div class="faq-a"><p>{a}</p></div></div>' for q, a in p['faq'])
    testi = ''.join(f'<div class="tc"><div class="tc-mark">"</div><p class="tc-txt">{t}</p>'
                    f'<div class="tc-div"></div><p class="tc-name">{n}</p></div>' for t, n in p['testi'])
    centres = ''.join(
      f'<a class="ccard" href="/centres/{c["slug"]}"><div class="city">{c["ville"]}</div>'
      f'<div class="addr">{c["rue"]}<br>{c["cp"]}</div><span class="go">Voir le centre →</span></a>'
      for c in CENTRES)

    body = f"""
<section class="phero">
  <div class="wrap">
    {crumb(('Nos accompagnements','/#accompagnements'), (p['nav'], None))}
    <p class="eyebrow">{p['eyebrow']}</p>
    <h1>{p['h1']}</h1>
    <p class="sub">{p['sub']}</p>
    <div class="hero-cta">
      <a href="#inscription" class="btn btn-pink btn-lg js-scroll">Réserver mon analyse offerte</a>
      <a href="tel:0466730200" class="btn btn-ghost">📞 04 66 73 02 00</a>
    </div>
    <div class="hero-trust">
      <span>⭐ <b>+8 ans</b>&nbsp;d'expérience</span>
      <span>👩‍⚕️ Séance <b>100% individuelle</b></span>
      <span>📍 <b>5 centres</b>&nbsp;dans le Sud</span>
    </div>
  </div>
</section>

<section class="pain">
  <div class="wrap center">
    <p class="eyebrow">On vous comprend</p>
    <h2 class="section-title">{p['intro_title']}</h2>
    <p class="section-lead">{p['intro_lead']}</p>
  </div>
  <div class="wrap">
    <div class="pcar"><div class="pcar-track" id="painTrack">{pains}</div>
    <div class="pcar-dots" id="painDots"></div></div>
  </div>
</section>

<section class="problems-band">
  <div class="wrap center">
    <p class="eyebrow">Nous agissons sur toutes les causes</p>
    <div class="pb-tags">{tags}</div>
  </div>
</section>

<section class="quote-band">
  <div class="wrap">
    <p>« {p['quote']} »</p>
    <small>{p['quote_sub']}</small>
  </div>
</section>

<section>
  <div class="wrap center">
    <p class="eyebrow">Le point de départ</p>
    <h2 class="section-title">Tout commence par une <span class="pink-text">analyse</span></h2>
    <p class="section-lead">{p['intro_body']}</p>
  </div>
  <div class="wrap"><div class="steps-grid">{steps}</div></div>
</section>

<section class="levers">
  <div class="wrap center">
    <p class="eyebrow">Les leviers activés</p>
    <h2 class="section-title">Les 4 piliers appliqués à votre parcours</h2>
    <p class="section-lead">Aucun levier n'est systématique : c'est votre analyse qui détermine lesquels sont
    pertinents, dans quel ordre et à quelle fréquence.</p>
  </div>
  <div class="wrap"><div class="pill-apply">{pil}</div></div>
</section>

<section>
  <div class="wrap center">
    <p class="eyebrow">Ce que ça change</p>
    <h2 class="section-title">Ce sur quoi nous travaillons avec vous</h2>
  </div>
  <div class="wrap"><div class="bengrid">{ben}</div></div>
</section>

<section class="approach">
  <div class="wrap center">
    <p class="eyebrow">Pour qui</p>
    <h2 class="section-title">{p['forwho_title']}</h2>
  </div>
  <div class="wrap"><div class="forwho"><ul>{who}</ul>
    <p style="margin-top:20px;padding-top:20px;border-top:1px solid var(--line);color:var(--teal-dark);
    font-weight:600;font-size:.96rem">{p['forwho_note']}</p></div></div>
</section>

<section class="testi" aria-label="Témoignages">
  <div class="wrap center">
    <p class="eyebrow">Témoignages</p>
    <h2 class="section-title">Ce qu'ils nous ont dit</h2>
    <p class="testi-lead">Les résultats évoqués sont propres à chaque personne et ne constituent pas une
    promesse de résultat.</p>
  </div>
  <div class="wrap">
    <div class="testi-grid" id="testiGrid">{testi}</div>
    <div class="testi-dots" id="testiDots"></div>
  </div>
</section>

{FORM}

<section class="faq" id="faq">
  <div class="wrap center">
    <p class="eyebrow">Questions fréquentes</p>
    <h2 class="section-title">Vous vous demandez sûrement…</h2>
  </div>
  <div class="wrap"><div class="faq-list" id="faqList">{faq}</div></div>
</section>

<section class="centers">
  <div class="wrap center">
    <p class="eyebrow">Près de chez vous</p>
    <h2 class="section-title">Où suivre cet accompagnement</h2>
  </div>
  <div class="wrap"><div class="center-grid">{centres}</div></div>
</section>
"""

    jsonld = {
      "@context":"https://schema.org",
      "@graph":[
        {"@type":"BreadcrumbList","itemListElement":[
          {"@type":"ListItem","position":1,"name":"Accueil","item":"https://www.mabeautyplus.fr/"},
          {"@type":"ListItem","position":2,"name":p['nav'],
           "item":f"https://www.mabeautyplus.fr/{p['slug']}"}]},
        {"@type":"FAQPage","mainEntity":[
          {"@type":"Question","name":q,
           "acceptedAnswer":{"@type":"Answer","text":a}} for q, a in p['faq']]},
      ]
    }
    return dict(path=f"/{p['slug']}", title=p['title'], desc=p['desc'],
                ogdesc=p['ogdesc'], body=body, jsonld=jsonld)
